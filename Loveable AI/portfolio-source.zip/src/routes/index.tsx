import { createFileRoute } from "@tanstack/react-router";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Skills } from "@/components/Skills";
import { Experience } from "@/components/Experience";
import { Projects } from "@/components/Projects";
import { Education } from "@/components/Education";
import { Organizations } from "@/components/Organizations";
import { Contact } from "@/components/Contact";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Muhammad Ahmad — QA Engineer & Webflow Developer" },
      {
        name: "description",
        content:
          "Muhammad Ahmad — QA Engineer, Webflow Developer & Project Manager. I build, test, and deliver high-performance websites end to end.",
      },
      { property: "og:title", content: "Muhammad Ahmad — QA Engineer & Webflow Developer" },
      {
        property: "og:description",
        content:
          "Portfolio of Muhammad Ahmad: Quality Assurance, Frontend & Webflow expertise — bridging the gap between building and breaking.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ThemeProvider>
      <main className="min-h-screen bg-background text-foreground">
        <Navbar />
        <Hero />
        <About />
        <Skills />
        <Experience />
        <Projects />
        <Education />
        <Organizations />
        <Contact />
      </main>
    </ThemeProvider>
  );
}
