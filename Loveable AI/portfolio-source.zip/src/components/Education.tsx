import { GraduationCap, Award } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

const education = [
  {
    title: "MSc Information Technology with Project Management",
    school: "University of the West of Scotland",
    meta: "Jan 2024 – Feb 2025 • London, UK",
    badge: "GPA 3.4",
  },
  {
    title: "BSc Computer Science",
    school: "University of Lahore",
    meta: "Feb 2016 – Jan 2021 • Lahore, Pakistan",
  },
];

const certs = [
  { title: "Fundamentals of Quality Assurance", issuer: "Alison" },
  { title: "QA Techniques and Methodologies", issuer: "Alison" },
  { title: "Programming Foundations: Software Testing", issuer: "LinkedIn" },
  { title: "Foundations of Project Management", issuer: "TEG – The Education Group, London" },
  { title: "Basics of Web Development & Coding", issuer: "Coursera" },
  { title: "Frontend Fundamentals", issuer: "Coursera" },
  { title: "JavaScript Basics", issuer: "University of California, Davis / Pirple" },
];

export function Education() {
  return (
    <section id="education" className="relative py-24 md:py-32 px-6 bg-surface/30">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
          <div>
            <SectionLabel number="05" label="Academic Background" />
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl tracking-tight">
              Education
            </h2>
          </div>
          <span className="font-display font-bold text-7xl md:text-9xl text-muted/40 leading-none">05</span>
        </div>

        <div className="grid md:grid-cols-2 gap-5 mb-16">
          {education.map((e) => (
            <div key={e.title} className="p-6 rounded-2xl bg-surface border border-border hover:border-brand/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="h-11 w-11 rounded-xl bg-brand/10 text-brand flex items-center justify-center shrink-0">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h3 className="font-display font-semibold text-lg mb-1">{e.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{e.school}</p>
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{e.meta}</span>
                    {e.badge && (
                      <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-brand/15 text-brand">{e.badge}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mb-8">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-brand mb-2">Continued Learning</p>
          <h3 className="font-display font-bold text-3xl md:text-4xl">Certifications</h3>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {certs.map((c) => (
            <div key={c.title} className="p-5 rounded-xl bg-surface border border-border hover:border-brand/40 transition-colors flex items-start gap-3">
              <Award className="h-5 w-5 text-brand shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-sm leading-snug">{c.title}</p>
                <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mt-1">{c.issuer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
