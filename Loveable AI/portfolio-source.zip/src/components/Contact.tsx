import { Mail, Phone, MapPin, Linkedin, ArrowRight } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

const channels = [
  { icon: Mail, label: "Email", value: "ahmadazhar955@gmail.com", href: "mailto:ahmadazhar955@gmail.com" },
  { icon: Phone, label: "Phone (PK)", value: "+92 304 4044436", href: "tel:+923044044436" },
  { icon: Phone, label: "Phone (UK)", value: "+44 7346 893954", href: "tel:+447346893954" },
  { icon: MapPin, label: "Location", value: "Lahore, Pakistan", href: "#" },
];

export function Contact() {
  return (
    <section id="contact" className="relative py-24 md:py-32 px-6 bg-hero">
      <div className="max-w-4xl mx-auto text-center">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-brand mb-6">— End of the Line</p>
        <h2 className="font-display font-bold text-5xl md:text-7xl lg:text-8xl tracking-tighter mb-6">
          Let's <span className="text-gradient">connect.</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-12 text-lg">
          Whether you have a role in mind, a project to test, or just want to talk quality — I'm
          always open to a good conversation.
        </p>

        <div className="grid sm:grid-cols-2 gap-4 mb-10 text-left">
          {channels.map((c) => (
            <a
              key={c.label}
              href={c.href}
              className="group p-5 rounded-xl bg-surface border border-border hover:border-brand/50 transition-colors flex items-center gap-4"
            >
              <div className="h-11 w-11 rounded-lg bg-brand/10 text-brand flex items-center justify-center group-hover:bg-brand group-hover:text-brand-foreground transition-colors">
                <c.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{c.label}</p>
                <p className="font-medium">{c.value}</p>
              </div>
            </a>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3">
          <a
            href="mailto:ahmadazhar955@gmail.com"
            className="inline-flex items-center gap-2 h-12 px-6 rounded-full bg-brand text-brand-foreground font-mono text-xs uppercase tracking-widest hover:shadow-glow transition-shadow"
          >
            Send a Message
            <ArrowRight className="h-4 w-4" />
          </a>
          <a
            href="https://linkedin.com/"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 h-12 px-6 rounded-full border border-border bg-surface font-mono text-xs uppercase tracking-widest hover:bg-surface-elevated transition-colors"
          >
            <Linkedin className="h-4 w-4" />
            View LinkedIn
          </a>
        </div>
      </div>

      <footer className="max-w-7xl mx-auto mt-24 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-mono uppercase tracking-widest text-muted-foreground">
        <p>© 2026 Muhammad Ahmad. Crafted with precision.</p>
        <p>Built end-to-end · Tested everywhere</p>
      </footer>
    </section>
  );
}
