import { SectionLabel } from "./SectionLabel";

const jobs = [
  {
    role: "Webflow Developer",
    company: "Deadon Agency",
    meta: "Contract • Remote",
    date: "Feb 2024 – Jun 2024",
    points: [
      "Developed and launched responsive websites using Webflow, focusing on performance, usability, and structured layouts",
      "Analyzed user interaction patterns and page behavior to improve engagement and conversion flow",
      "Worked with project requirements, timelines, and delivery metrics to support data-informed decisions",
      "Collaborated with design and marketing teams, translating requirements into measurable outcomes",
    ],
  },
  {
    role: "Frontend Developer",
    company: "Deal.ai",
    meta: "Contract • Remote",
    date: "Dec 2023 – Feb 2024",
    points: [
      "Built marketing funnel pages from scratch using HTML, CSS, and JavaScript",
      "Translated requirements into clean, responsive UI designs ensuring seamless performance across all screen sizes",
      "Conducted thorough responsiveness testing to maintain high-quality user experience",
    ],
  },
  {
    role: "Software Engineer / Expert Webflow Developer",
    company: "Punch Group",
    meta: "Full-Time • Lahore",
    date: "Nov 2022 – Dec 2023",
    points: [
      "Led the development of responsive websites and web applications using Webflow, HTML, and CSS",
      "Incorporated Webflow Interactions and custom animations for enhanced user engagement",
      "Collaborated with cross-functional teams to deliver high-performance web solutions",
    ],
  },
  {
    role: "Webflow Expert",
    company: "Punch Group",
    meta: "Full-Time • Lahore",
    date: "Jun 2021 – Oct 2022",
    points: [
      "Designed and developed custom websites on Webflow, managing end-to-end projects from concept to launch",
      "Focused on optimizing performance and ensuring scalability",
    ],
  },
  {
    role: "Frontend Developer",
    company: "Punch Group",
    meta: "Full-Time • Lahore",
    date: "Feb 2021 – May 2021",
    points: [
      "Developed front-end interfaces using HTML, CSS, and Bootstrap",
      "Collaborated with teams to implement version control and streamline workflows",
    ],
  },
  {
    role: "Shopify Developer",
    company: "Punch Group",
    meta: "Full-Time • Lahore",
    date: "Oct 2020 – Jan 2021",
    points: [
      "Customized Shopify themes using HTML5, CSS, JQuery and JavaScript",
      "Integrated apps and tailored templates to align with client needs",
    ],
  },
  {
    role: "Shopify Developer",
    company: "MAS Group, LLC",
    meta: "Full-Time • West Hollywood, CA",
    date: "May 2020 – Aug 2020",
    points: [
      "Developed and maintained Shopify storefronts focused on conversion-optimized layouts",
      "Implemented theme customizations and ensured cross-browser compatibility",
    ],
  },
];

export function Experience() {
  return (
    <section id="experience" className="relative py-24 md:py-32 px-6 bg-surface/30">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
          <div>
            <SectionLabel number="03" label="Professional Path" />
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl tracking-tight">
              Experience
            </h2>
          </div>
          <span className="font-display font-bold text-7xl md:text-9xl text-muted/40 leading-none">03</span>
        </div>

        <div className="relative">
          <div className="absolute left-4 md:left-1/2 top-2 bottom-2 w-px bg-border md:-translate-x-1/2" />

          <div className="space-y-8">
            {jobs.map((j, i) => (
              <div key={i} className="relative pl-12 md:pl-0 md:grid md:grid-cols-2 md:gap-10">
                <div className={`absolute left-2.5 md:left-1/2 top-6 h-3 w-3 rounded-full bg-brand md:-translate-x-1/2 shadow-glow`} />

                <div className={`${i % 2 === 0 ? "md:text-right md:pr-10" : "md:order-2 md:pl-10"}`}>
                  <p className="font-mono text-xs uppercase tracking-widest text-brand mb-2">{j.date}</p>
                  <h3 className="font-display font-bold text-xl mb-1">{j.role}</h3>
                  <p className="text-sm text-muted-foreground">
                    <span className="text-foreground font-medium">{j.company}</span> · {j.meta}
                  </p>
                </div>

                <div className={`${i % 2 === 0 ? "md:pl-10 mt-3 md:mt-0" : "md:order-1 md:text-right md:pr-10 mt-3 md:mt-0"}`}>
                  <ul className="space-y-2">
                    {j.points.map((p, k) => (
                      <li key={k} className={`text-sm text-muted-foreground leading-relaxed flex gap-2 ${i % 2 === 0 ? "" : "md:flex-row-reverse md:text-right"}`}>
                        <span className="text-brand shrink-0">▸</span>
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
