import { ArrowRight, Mail } from "lucide-react";
import { motion } from "framer-motion";

export function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex items-center justify-center bg-hero overflow-hidden pt-16">
      <div className="absolute inset-0 grid-bg opacity-20 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />

      <div className="relative max-w-5xl mx-auto px-6 text-center">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground mb-6"
        >
          ◆ Hey, I'm
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-display font-bold text-2xl sm:text-3xl text-muted-foreground mb-4"
        >
          MUHAMMAD AHMAD
        </motion.h1>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="font-display font-bold text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[0.95] tracking-tighter mb-8"
        >
          I BUILD, TEST, AND <br className="hidden sm:block" />
          DELIVER{" "}
          <span className="text-gradient">HIGH-PERFORMANCE WEBSITES</span>{" "}
          <span className="text-muted-foreground">— END TO END, WITH NO GAPS.</span>
        </motion.h2>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 font-mono text-xs uppercase tracking-widest text-muted-foreground mb-10"
        >
          <span>Webflow Developer</span>
          <span className="h-1 w-1 rounded-full bg-brand" />
          <span>QA Engineer</span>
          <span className="h-1 w-1 rounded-full bg-brand" />
          <span>Project Manager</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex flex-wrap items-center justify-center gap-3"
        >
          <a
            href="#projects"
            className="group inline-flex items-center gap-2 h-12 px-6 rounded-full bg-brand text-brand-foreground font-mono text-xs uppercase tracking-widest hover:shadow-glow transition-all"
          >
            View My Work
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 h-12 px-6 rounded-full border border-border bg-surface/50 backdrop-blur font-mono text-xs uppercase tracking-widest hover:bg-surface transition-colors"
          >
            <Mail className="h-4 w-4" />
            Contact Me
          </a>
        </motion.div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
        Scroll to explore ↓
      </div>
    </section>
  );
}
