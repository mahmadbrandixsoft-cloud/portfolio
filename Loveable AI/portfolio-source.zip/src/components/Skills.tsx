import { SectionLabel } from "./SectionLabel";

const marquee = ["Webflow", "HTML5", "CSS3", "JavaScript", "React", "Shopify", "WordPress", "Jira", "Git"];

const groups = [
  { num: "01", title: "Quality Assurance", items: ["SDLC & Agile Basics", "Manual Testing", "Test Case & Scenario Understanding", "Requirement Review", "Defect Identification"] },
  { num: "02", title: "Programming & Markup", items: ["HTML5", "CSS3", "JavaScript", "JQuery", "React"] },
  { num: "03", title: "Tools & Platforms", items: ["Jira", "ClickUp", "Microsoft Teams", "Git"] },
  { num: "04", title: "Data & Analytics", items: ["SQL (Basic Queries)", "Excel", "Python (pandas, basic)"] },
  { num: "05", title: "CMS & Website Builders", items: ["WordPress", "Webflow", "Shopify", "Wix"] },
  { num: "06", title: "Soft Skills", items: ["Attention to Detail", "Communication", "Analytical Thinking", "Time Management"] },
];

export function Skills() {
  return (
    <section id="skills" className="relative py-24 md:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-10">
          <div>
            <SectionLabel number="02" label="Technical Arsenal" />
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl tracking-tight">
              Skills & Expertise
            </h2>
          </div>
          <span className="font-display font-bold text-7xl md:text-9xl text-muted/40 leading-none">02</span>
        </div>

        {/* Marquee */}
        <div className="relative my-12 py-5 border-y border-border overflow-hidden">
          <div className="flex animate-marquee whitespace-nowrap">
            {[...marquee, ...marquee].map((t, i) => (
              <span key={i} className="font-display font-semibold text-2xl md:text-3xl mx-8 text-muted-foreground hover:text-brand transition-colors">
                {t} <span className="text-brand mx-3">◆</span>
              </span>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {groups.map((g) => (
            <div key={g.num} className="p-6 rounded-2xl bg-surface border border-border hover:border-brand/40 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <span className="font-mono text-xs text-brand">{g.num}</span>
                <h3 className="font-display font-semibold text-lg uppercase tracking-wide">{g.title}</h3>
              </div>
              <ul className="space-y-2">
                {g.items.map((i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-center gap-2">
                    <span className="h-1 w-1 rounded-full bg-brand" />
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
