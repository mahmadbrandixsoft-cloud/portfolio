export function SectionLabel({ number, label }: { number: string; label: string }) {
  return (
    <div className="flex items-center gap-3 mb-6 font-mono text-xs uppercase tracking-[0.25em] text-brand">
      <span>{number}</span>
      <span className="h-px w-12 bg-brand/50" />
      <span className="text-muted-foreground">{label}</span>
    </div>
  );
}
