import { ShieldCheck, Code2, Bug } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

const cards = [
  {
    icon: ShieldCheck,
    title: "Quality Assurance",
    text: "Manual testing, SDLC, requirement analysis, and defect identification to ensure robust applications.",
  },
  {
    icon: Code2,
    title: "Frontend Craft",
    text: "Translating complex requirements into clean, responsive, and highly performant user interfaces.",
  },
  {
    icon: Bug,
    title: "Defect Tracking",
    text: "Systematic bug reporting and collaboration with developers to maintain high-quality standards.",
  },
];

export function About() {
  return (
    <section id="about" className="relative py-24 md:py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionLabel number="01" label="About Me" />

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 mb-16">
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl leading-tight tracking-tight">
            Bridging the gap between <span className="text-gradient">building</span> and{" "}
            <span className="text-gradient">breaking</span>.
          </h2>
          <div className="space-y-5 text-muted-foreground leading-relaxed">
            <p>
              I am a Quality Assurance professional with a Master's degree in IT and Project
              Management from the University of the West of Scotland. My foundation in computer
              science and extensive background in frontend development give me a unique edge in QA.
            </p>
            <p>
              Because I know how applications are built, I know exactly where they might break.
              This technical perspective enables highly effective manual testing, sharp requirement
              analysis, and precise defect identification.
            </p>
            <p>
              I am detail-oriented, a strong communicator, and highly experienced in collaborating
              with both developers and non-technical stakeholders. My clear goal is to grow further
              into Manual QA and Automation Testing roles, ensuring digital products perform
              flawlessly.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {cards.map((c) => (
            <div
              key={c.title}
              className="group p-6 rounded-2xl bg-surface border border-border hover:border-brand/50 hover:shadow-card transition-all"
            >
              <div className="h-11 w-11 rounded-xl bg-brand/10 text-brand flex items-center justify-center mb-5 group-hover:bg-brand group-hover:text-brand-foreground transition-colors">
                <c.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">{c.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{c.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
