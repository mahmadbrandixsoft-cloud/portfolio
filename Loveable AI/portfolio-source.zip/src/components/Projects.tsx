import { ArrowUpRight, Layers, ShoppingBag } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

const projects = [
  {
    icon: Layers,
    title: "The Highest of Stakes",
    client: "Punch Group",
    text: "Developed Webflow layouts and integrated CMS, also reviewing functionality for UI consistency, responsiveness, and performance to ensure a high-quality user experience.",
    tags: ["Webflow", "CMS", "UI/UX Review", "Performance Testing"],
  },
  {
    icon: ShoppingBag,
    title: "DressBarn",
    client: "RashFlash",
    text: "Responsible for developing Shopify pages and customizations for UI/UX consistency, responsiveness, and functionality, identifying issues to ensure a smooth and high-quality user experience.",
    tags: ["Shopify", "Customization", "QA", "Defect Identification"],
  },
];

export function Projects() {
  return (
    <section id="projects" className="relative py-24 md:py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
          <div>
            <SectionLabel number="04" label="Featured Work" />
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl tracking-tight">
              Key Projects
            </h2>
          </div>
          <span className="font-display font-bold text-7xl md:text-9xl text-muted/40 leading-none">04</span>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((p) => (
            <article
              key={p.title}
              className="group relative p-8 rounded-3xl bg-surface border border-border hover:border-brand/50 transition-all overflow-hidden"
            >
              <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-brand/10 blur-3xl group-hover:bg-brand/20 transition-all" />

              <div className="relative">
                <div className="flex items-start justify-between mb-6">
                  <div className="h-12 w-12 rounded-xl bg-brand/10 text-brand flex items-center justify-center">
                    <p.icon className="h-6 w-6" />
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-muted-foreground group-hover:text-brand group-hover:-translate-y-1 group-hover:translate-x-1 transition-all" />
                </div>

                <h3 className="font-display font-bold text-2xl mb-2">{p.title}</h3>
                <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">
                  Client: <span className="text-brand">{p.client}</span>
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed mb-6">{p.text}</p>

                <div className="flex flex-wrap gap-2 pt-4 border-t border-border">
                  {p.tags.map((t) => (
                    <span key={t} className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
