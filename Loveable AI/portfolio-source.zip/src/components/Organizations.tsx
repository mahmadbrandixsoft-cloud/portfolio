import { Users, Heart } from "lucide-react";
import { SectionLabel } from "./SectionLabel";

const orgs = [
  {
    icon: Users,
    title: "School Officer — Computer Engineering & Physical Sciences (CEPS)",
    text: "Representing students in the School of Computing Engineering and Physical Sciences at the University of the West of Scotland. Acting as liaison between students and faculty, responsible for managing events and workshops.",
  },
  {
    icon: Heart,
    title: "Volunteer — Blood Donation Society",
    text: "Coordinated donors and hospitals to ensure timely blood availability. Supported logistics for multiple blood donation drives.",
  },
];

export function Organizations() {
  return (
    <section className="relative py-24 md:py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
          <div>
            <SectionLabel number="06" label="Beyond the Screen" />
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl tracking-tight">
              Organizations
            </h2>
          </div>
          <span className="font-display font-bold text-7xl md:text-9xl text-muted/40 leading-none">06</span>
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          {orgs.map((o) => (
            <div key={o.title} className="p-7 rounded-2xl bg-surface border border-border hover:border-brand/40 transition-colors">
              <div className="h-11 w-11 rounded-xl bg-brand/10 text-brand flex items-center justify-center mb-5">
                <o.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-3">{o.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{o.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
